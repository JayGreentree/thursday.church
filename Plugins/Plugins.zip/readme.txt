﻿This directory is for storing custom third-party plugins.

Folder structure should be similar to...

RockWeb
    Plugins
	    org_rocksolidchurch
			SampleProject
				SampleBlock.ascx
				SampleBlock.ascx.cs